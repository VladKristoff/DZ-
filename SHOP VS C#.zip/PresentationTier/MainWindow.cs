﻿using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Магазин магазин;
    public MainWindow()
    {
        InitializeComponent();

    }

    public void Button_Click(object sender, RoutedEventArgs e)
    {
        List<Товар> товар = ВсеТовары.ПолучитьВсеТоварыИзФайла();
        if (товар.Count == 0)
        {
            MessageBox.Show("Нет товаров в файле");
            return;
        }
        List<ТоварнаяПозиация> позиции = new List<ТоварнаяПозиация>();
        foreach (var p in товар)
        {
            позиции.Add(new ТоварнаяПозиация(p));
        }
        магазин = new Магазин(позиции);



        this.DataContext = магазин;
    }
    public void BtnAdd_Click(object sender, RoutedEventArgs e)
    {
        // 1. Открываем диалог сохранения файла
        Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();
        saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
        saveFileDialog.Title = "Сохранить товар";

        // Показываем диалог и проверяем, что пользователь нажал "OK"
        if (saveFileDialog.ShowDialog() != true)
        {
            return; // Если нажали "Отмена" — выходим
        }

        string filePath = saveFileDialog.FileName; // Получаем путь только после ShowDialog()

        // 2. Получаем данные из TextBox-ов (без привязки)
        string товар = tovar.Text; // Просто обращаемся по имени
        string товарнаяГруппа = group_tovar.Text;
        string ценаЗакупки = price_buy.Text;
        string ценаПродажи = price_sell.Text;

        // 3. Проверяем, что все поля заполнены
        if (string.IsNullOrWhiteSpace(товар) ||
            string.IsNullOrWhiteSpace(товарнаяГруппа) ||
            string.IsNullOrWhiteSpace(ценаЗакупки) ||
            string.IsNullOrWhiteSpace(ценаПродажи))
        {
            MessageBox.Show("Заполните все поля!");
            return;
        }

        // 4. Проверяем, что цены — числа
        if (!float.TryParse(ценаЗакупки, out float закупка) ||
            !float.TryParse(ценаПродажи, out float продажа))
        {
            MessageBox.Show("Цены должны быть числами!");
            return;
        }

        // 5. Формируем строку для записи (разделитель "%" как в вашем проекте)
        string строкаДляЗаписи = $"{товар}%{товарнаяГруппа}%{закупка}%{продажа}";

        // 6. Записываем в файл
        try
        {
            File.AppendAllText(filePath, строкаДляЗаписи + Environment.NewLine, Encoding.UTF8);

        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
        }
    }
}