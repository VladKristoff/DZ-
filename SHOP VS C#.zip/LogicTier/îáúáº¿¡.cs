﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataTier;
using System.Collections.ObjectModel;

namespace LogicTier
{
    public class Магазин
    {
        private List<ТоварнаяПозиация> _товарыПозиции;
        public class ГруппаСтоимостей
        {
            public string ТоварнаяГруппа { get; set; }
            public float СуммарнаяСтоимость { get; set; }

            // Добавляем свойство для отображения в ListBox
            public string ПредставлениеГруппы
            {
                get { return $"{ТоварнаяГруппа} — {СуммарнаяСтоимость} ₽"; }
            }
        }

        public Магазин(List<ТоварнаяПозиация> позиции)
        {
            _товарыПозиции = позиции;
            ГруппыСтоимостей = СуммарнаяСтоимостьТоваровПоГруппе();
            СамыеДорогиеТовары = СамыйДорогойТоварВКаждойГруппе();
        }
        public List<ТоварнаяПозиация> СписокТоваров => _товарыПозиции;
        public ObservableCollection<ГруппаСтоимостей> ГруппыСтоимостей { get; }
        public ObservableCollection<СамыйДорогойТоварViewModel> СамыеДорогиеТовары { get; }

        public string НаименованиеМагазина
        {
            get { return "Наш магазин"; }
        }

        public ObservableCollection<ГруппаСтоимостей> СуммарнаяСтоимостьТоваровПоГруппе()
        {
            return new ObservableCollection<ГруппаСтоимостей>(
                _товарыПозиции
                    .GroupBy(p => p.ТоварнаяГруппа)
                    .Select(group => new ГруппаСтоимостей { ТоварнаяГруппа = group.Key, СуммарнаяСтоимость = group.Sum(p => p.ЦенаПродажи) })
                    .OrderBy(g => g.ТоварнаяГруппа) // Optional sorting
            );
        }

        public ObservableCollection<СамыйДорогойТоварViewModel> СамыйДорогойТоварВКаждойГруппе()
        {
            return new ObservableCollection<СамыйДорогойТоварViewModel>(
                _товарыПозиции
                    .GroupBy(p => p.ТоварнаяГруппа)
                    .Select(group => group.OrderByDescending(p => p.ЦенаПродажи).FirstOrDefault())
                    .Where(item => item != null) // Avoid nulls if a group is empty
                    .Select(item => new СамыйДорогойТоварViewModel { Товар = item.товар, ТоварнаяГруппа = item.ТоварнаяГруппа, ЦенаПродажи = item.ЦенаПродажи })
                    .OrderBy(vm => vm.ТоварнаяГруппа) // Optional sorting
            );
        }
    }

    public class ГруппаСтоимостей
    {
        public string ТоварнаяГруппа { get; set; }
        public float СуммарнаяСтоимость { get; set; }
    }

    public class СамыйДорогойТоварViewModel
    {
        public string Товар { get; set; }
        public string ТоварнаяГруппа { get; set; }
        public float ЦенаПродажи { get; set; }
    }
}