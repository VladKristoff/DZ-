﻿
using DataTier;
using System.Windows.Shapes;

namespace LogicTier
{
    public class ТоварнаяПозиация
    {
        private Товар _товар;

        public ТоварнаяПозиация(Товар p)
        {
            _товар = p;
        }
        public string товар
        {
            get { return _товар.товар; }
            set { _товар.товар = value; }
        }
        public string ТоварнаяГруппа
        {
            get { return _товар.ТоварнаяГруппа; }
            set { _товар.ТоварнаяГруппа = value; }
        }
        public float ЦенаЗакупки
        {
            get { return _товар.ЦенаЗакупки; }
            set { _товар.ЦенаЗакупки = value; }
        }
        public float ЦенаПродажи
        {
            get { return _товар.ЦенаПродажи; }
            set { _товар.ЦенаПродажи = value; }
        }
        public string ПредставлениеТовара
        {
            get { return $"{товар} ({ТоварнаяГруппа}) - Цена: {ЦенаПродажи} $"; }
        }
        
    }

}
