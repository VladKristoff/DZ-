﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DataTier
{
    public class ВсеТовары
    {
        public static List<Товар> ПолучитьВсеТоварыИзФайла()
        {
            List<Товар> list = new List<Товар>();

            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                string FilePath = openFileDialog.FileName;
                using (StreamReader sreader = new StreamReader(FilePath, Encoding.UTF8))
                {
                    while (!sreader.EndOfStream)
                    {
                        string[] line = sreader.ReadLine().Split("%");

                        Товар tovar = new Товар()
                        {
                            товар = line[0],
                            ТоварнаяГруппа = line[1],
                            ЦенаЗакупки = float.Parse(line[2]),
                            ЦенаПродажи = float.Parse(line[3]),
                        };
                        list.Add(tovar);
                    }
                }
            }
            return list;
        }
    }
}
